EnableShield = 0x80122e60
AddToWorld = 0x8010e9cc
Attach_UnitMtxToParent_PS = 0x80110dbc

.macro call addr
  lis r12,  \addr@h
  ori r12, r12, \addr@l
  mtlr r12
  blrl
.endm

stfs f1,0xdf4(r26)

lwz r3,0x91c(r26)
cmplwi r3,0x0
beq Branch
call AddToWorld
lis r3,-0x7fc4
lis r4,-0x7fb6
subi r5,r3,0xf78
lwz r3,0x91c(r26)
lwz r5,0x10(r5)
subi r6,r4,0x728
or r4,r26,r26
li r7,0x0
call Attach_UnitMtxToParent_PS
lwz r3,0x91c(r26)
li r4,0x1
call EnableShield
lwz r3,0x91c(r26)
li r0,0x0
stw r0,0x1e0(r3)
Branch: