FindArmorProfile = 0x801817a8
SetHealthContainerCount = 0x8010d6e4

.macro call addr
  lis r12,  \addr@h
  ori r12, r12, \addr@l
  mtlr r12
  blrl
.endm

lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r15, {{ SHIELDRECHARGE_MEMORY }}@h
ori r15, r15, {{ SHIELDRECHARGE_MEMORY }}@l
add r15,r12,r15
lfs f1,0x0(r15)
lfs f0,-0x4200(r2)
fcmpo cr0,f1,f0
bge SetShieldRecharge
lfs f1,0x18(r3)
SetShieldRecharge:
stfs f1,0x14(r1)
or r17,r4,r4
or r18,r5,r5
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r15, {{ SHIELDARMORPROFILE_MEMORY }}@h
ori r15, r15, {{ SHIELDARMORPROFILE_MEMORY }}@l
add r15,r12,r15
lwz r3,0x0(r15)
cmplwi r3,0x0
bne SetArmorProfile
or r3,r0,r0
b StoreArmor
SetArmorProfile:
li r4,0x1
li r5,0x1
call FindArmorProfile
StoreArmor:
stw r3,0x18(r1)

lwz r3,0x91c(r31)
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r15, {{ SHIELDHEALTH_MEMORY }}@h
ori r15, r15, {{ SHIELDHEALTH_MEMORY }}@l
add r15,r12,r15
lfs f1,0x0(r15)
call SetHealthContainerCount

or r4,r17,r17
or r5,r18,r18