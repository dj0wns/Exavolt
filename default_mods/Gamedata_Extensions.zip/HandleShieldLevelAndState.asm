_ShieldOn = 0x80123db8
SetUnitHealth = 0x8010d798

.macro call addr
  lis r12,  \addr@h
  ori r12, r12, \addr@l
  mtlr r12
  blrl
.endm

stwu r1,-0x20(r1)
mfspr r0,LR
stw r0,0x24(r1)
stfd f31,0x10(r1)
psq_st f31,0x18(r1),0x0,GQR0
stw r31,0xc(r1)
or r31,r3,r3
lfs f0,-0x5338(r2)
lfs f2,0x168(r3)
lfs f1,0x164(r3)
fmuls f31,f2,f1
fcmpo cr0,f31,f0
ble Branch1
fmr f31,f0

Branch1:
lfs f0,-0x5338(r2)
fcmpo cr0,f31,f0
bge End
lfs f1,0x1d0(r31)
lfs f0,-0x5334(r2)
fcmpo cr0,f1,f0
bge Branch4
fcmpo cr0,f2,f0
bgt Branch2
or r3,r31,r31
call _ShieldOn

Branch2:
lfs f2,-0x1718(r13)
lfs f1,0x1c8(r31)
lfs f0,-0x5338(r2)
fmadds f31,f2,f1,f31
fcmpo cr0,f31,f0
ble Branch3
fmr f31,f0

Branch3:
fmr f1,f31
or r3,r31,r31
call SetUnitHealth
stfs f31,0x1d4(r31)
b End

Branch4:
lfs f0,-0x1718(r13)
fsubs f0,f1,f0
stfs f0,0x1d0(r31)

End:
psq_l f31,0x18(r1),0x0,GQR0
lwz r0,0x24(r1)
lfd f31,0x10(r1)
lwz r31,0xc(r1)
mtspr LR,r0
addi r1,r1,0x20
blr