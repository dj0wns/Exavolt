RemoveFromWorld = 0x8010ea88

.macro call addr
  lis r12,  \addr@h
  ori r12, r12, \addr@l
  mtlr r12
  blrl
.endm

lwz r3,0x91c(r31)
cmplwi r3,0x0
beq Branch
li r4,0x0
call RemoveFromWorld
Branch:
or r3,r31,r31