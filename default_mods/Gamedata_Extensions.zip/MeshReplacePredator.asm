fresload_Load_Main = 0x8028fdf0

.macro call addr
  lis r12,  \addr@h
  ori r12, r12, \addr@l
  mtlr r12
  blrl
.endm

lwz r0,0xdb4(r30)
lis r3,-0x7fc6
addi r3,r3,0x5798
cmpwi r0,0x0
addi r4,r3,0x34
beq Branch
or r4,r0,r0
Branch:
lis r3,-0x7fc6
li r5,0x0
addi r3,r3,0x5798
addi r3,r3,0x2f
call fresload_Load_Main
stw r3,-0x2db0(r13)
li r3,0x1d8