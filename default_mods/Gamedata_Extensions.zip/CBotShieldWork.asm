ShieldWork = 0x80123224

.macro call addr
  lis r12,  \addr@h
  ori r12, r12, \addr@l
  mtlr r12
  blrl
.endm

lwz r5,0x138(r31)
li r4,0x0
lwz r6,0x13c(r31)
lis r3,0x20
and r0,r5,r4
and r3,r6,r3
xor r3,r3,r4
xor r0,r0,r4
or. r0,r3,r0
bne NoWork
li r0,0x1
and r3,r6,r4
and r0,r5,r0
xor r3,r3,r4
xor r0,r0,r4
or. r0,r3,r0
bne NoWork
lwz r3,0x91c(r31)
cmplwi r3,0x0
beq NoWork
call ShieldWork
NoWork:
lfs f2,0x98c(r31)