lis r3,-0x7fc5
subi r30,r3,0x7b60
addi r4,r30,0xc
addi r29,r30,0x18

lis r12,-0x7fc0
addi r12,r12,0x4b18
lwz r0,0xdb4(r12)
cmplwi r0,0x0
beq Branch1
or r4,r0,r0
Branch1:
lis r19, {{ SCRATCH_MEMORY_POINTER }}@h
ori r19, r19, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r19,0x0(r19)
lis r12, {{ DEADMESHREPLACE_MEMORY }}@h
ori r12, r12, {{ DEADMESHREPLACE_MEMORY }}@l
add r12,r19,r12
lwz r0,0x0(r12)
cmplwi r0,0x0
beq Branch2
or r29,r0,r0
Branch2:
lis r3,-0x7fc5