SetTint = 0x80122e1c

.macro call addr
  lis r12,  \addr@h
  ori r12, r12, \addr@l
  mtlr r12
  blrl
.endm

lwz r3,0x91c(r31)
cmplwi r3,0x0
beq Branch
addi r4,r1,0x8
lfs f4,-0x7bf0(r13)
lfs f3,-0x72c0(r2)
stfs f4,0x8(r1)
stfs f3,0x10(r1)
stfs f3,0xc(r1)
lwz r3,0x91c(r31)
call SetTint
Branch:
or r3,r31,r31