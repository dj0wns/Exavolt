SetHealthContainerCount = 0x8010d6e4

.macro call addr
  lis r12,  \addr@h
  ori r12, r12, \addr@l
  mtlr r12
  blrl
.endm

stfs f0,0xc(r1)
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r15, {{ SHIELDRECHARGE_MEMORY }}@h
ori r15, r15, {{ SHIELDRECHARGE_MEMORY }}@l
add r15,r12,r15
lfs f1,0x0(r15)
lfs f0,-0x4200(r2)
fcmpo cr0,f1,f0
bge SetShieldRecharge
lis r3,-0x7fb8
subi r3,r3,0x7824
lfs f1,0x6c(r3)
SetShieldRecharge:
stfs f1,0x14(r1)
or r16,r3,r3
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r15, {{ SHIELDARMORPROFILE_MEMORY }}@h
ori r15, r15, {{ SHIELDARMORPROFILE_MEMORY }}@l
add r15,r12,r15
lwz r3,0x0(r15)
cmplwi r3,0x0
bne SetArmorProfile
lwz r3,0x74(r16)
SetArmorProfile:
or r16,r3,r3
lwz r3,0x91c(r31)
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r15, {{ SHIELDHEALTH_MEMORY }}@h
ori r15, r15, {{ SHIELDHEALTH_MEMORY }}@l
add r15,r12,r15
lfs f1,0x0(r15)
call SetHealthContainerCount
or r3,r16,r16