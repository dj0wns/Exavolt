_fres_AlignedAlloc = 0x8028fa88
CEShield = 0x80122778
ShieldCreate = 0x801228b4
ShieldInit = 0x80122d14
RemoveFromWorld = 0x8010ea88
EntityDestroy = 0x8010cecc
_fres_ReleaseFrame = 0x8028fafc
FindArmorProfile = 0x801817a8

.macro call addr
  lis r12,  \addr@h
  ori r12, r12, \addr@l
  mtlr r12
  blrl
.endm

li r3,0x1

lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)

lis r4, {{ SHIELD_STATE_MEMORY }}@h
ori r4, r4, {{ SHIELD_STATE_MEMORY }}@l
add r4,r12,r4
lwz r0,0x0(r4)
cmpwi r0,0x0
beq Branch1
li r3,0x210
li r4,0x8
call _fres_AlignedAlloc
or. r0,r3,r3
beq Branch2
call CEShield
or r0,r3,r3

Branch2:
stw r0,0x91c(r31)
bl shieldname_string
.string "MortarShield"
.align 2
shieldname_string:
mflr r4
li r5,0x0
lwz r3,0x91c(r31)
li r6,0x0
call ShieldCreate
cmpwi r3,0x0
beq Branch3
li r7,0x8
stw r7,0x8(r1)
lfs f2,-0x57d8(r13)
stfs f2,0x10(r1)
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r15, {{ SHIELDRECHARGE_MEMORY }}@h
ori r15, r15, {{ SHIELDRECHARGE_MEMORY }}@l
add r15,r12,r15
lfs f1,0x0(r15)
lfs f0,-0x4200(r2)
fcmpo cr0,f1,f0
bge SetShieldRecharge
lfs f1,-0x3760(r2)
SetShieldRecharge:
stfs f1,0x14(r1)
lfs f0,-0x610c(r13)
stfs f0,0xc(r1)
li r4,0x1
li r5,0x1
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r15, {{ SHIELDARMORPROFILE_MEMORY }}@h
ori r15, r15, {{ SHIELDARMORPROFILE_MEMORY }}@l
add r15,r12,r15
lwz r3,0x0(r15)
cmplwi r3,0x0
bne SetArmorProfile
bl armorprofile_string
.string "titan shield"
.align 2
armorprofile_string:
mflr r3
SetArmorProfile:
call FindArmorProfile
stw r3,0x18(r1)
or r4,r31,r31
addi r5,r1,0x8
li r6,0x1
lwz r3,0x91c(r31)
call ShieldInit
lwz r3,0x91c(r31)
li r4,0x0
call RemoveFromWorld

Branch1:
li r3,0x1
b End

Branch3:
or r3,r31,r31
call EntityDestroy
or r3,r28,r28
call _fres_ReleaseFrame
li r3,0x0

End:
lmw r20,0x60(r1)
lwz r0,0x94(r1)
mtspr LR,r0
addi r1,r1,0x90
blr
