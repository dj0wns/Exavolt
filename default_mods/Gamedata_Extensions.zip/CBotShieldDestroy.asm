or r15,r3,r3
lwz r3,0x91c(r31)
cmplwi r3,0x0
beq Branch1
beq Branch2
lwz r12,0x1a0(r3)
li r4,0x1
lwz r12,0x8(r12)
mtspr CTR,r12
bctrl
Branch2:
li r0,0x0
stw r0,0x91c(r31)
Branch1:
or r3,r15,r15
lwz r3,0x1bc(r3)