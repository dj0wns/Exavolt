fclib_stricmp = 0x80280508
Interpret_String = 0x80113ad0
Interpret_F32 = 0x801142a4
Error_InvalidParameterValue = 0x8011453c

.macro call addr
  lis r12,  \addr@h
  ori r12, r12, \addr@l
  mtlr r12
  blrl
.endm

lwz r3,-0x2978(r13)
bl deadmesh_string
.string "DeadMeshReplace"
.align 2
deadmesh_string:
mflr r4
call fclib_stricmp
cmpwi r3,0x0
bne ShieldArmorProfile
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r31, {{ DEADMESHREPLACE_MEMORY }}@h
ori r31, r31, {{ DEADMESHREPLACE_MEMORY }}@l
add r31,r12,r31
addi r3,r31,0x0
li r4,0x1
li r5,0x0
li r6,0x0
call Interpret_String
li r3,0x1
b End

ShieldArmorProfile:
lwz r3,-0x2978(r13)
bl shieldarmorprofile_string
.string "ShieldArmorProfile"
.align 2
shieldarmorprofile_string:
mflr r4
call fclib_stricmp
cmpwi r3,0x0
bne ShieldRecharge
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r31, {{ SHIELDARMORPROFILE_MEMORY }}@h
ori r31, r31, {{ SHIELDARMORPROFILE_MEMORY }}@l
add r31,r12,r31
addi r3,r31,0x0
li r4,0x1
li r5,0x0
li r6,0x0
call Interpret_String
li r3,0x1
b End

ShieldRecharge:
lwz r3,-0x2978(r13)
bl shieldrecharge_string
.string "ShieldRecharge"
.align 2
shieldrecharge_string:
mflr r4
call fclib_stricmp
cmpwi r3,0x0
bne ShieldHealth
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r31, {{ SHIELDRECHARGE_MEMORY }}@h
ori r31, r31, {{ SHIELDRECHARGE_MEMORY }}@l
add r31,r12,r31
addi r3,r31,0x0
lfs f1,-0x4308(r2)
lfs f2,-0x4304(r2)
li r4,0x0
call Interpret_F32
li r3,0x1
b End

ShieldHealth:
lwz r3,-0x2978(r13)
bl shieldhealth_string
.string "ShieldHealth"
.align 2
shieldhealth_string:
mflr r4
call fclib_stricmp
cmpwi r3,0x0
bne Shields
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r31, {{ SHIELDHEALTH_MEMORY }}@h
ori r31, r31, {{ SHIELDHEALTH_MEMORY }}@l
add r31,r12,r31
addi r3,r31,0x0
lfs f1,-0x756c(r2)
lfs f2,-0x7564(r2)
li r4,0x0
call Interpret_F32
li r3,0x1
b End

Shields:
lis r4,-0x7fc6
lwz r3,-0x2978(r13)
addi r4,r4,0x2d00
addi r4,r4,0x39
call fclib_stricmp
cmpwi r3,0x0
bne Next
addi r3,r1,0x14
li r4,0x1
li r5,0x0
li r6,0x0
call Interpret_String
cmpwi r3,0x0
beq Exit
lis r4,-0x7fc6
lwz r3,0x14(r1)
addi r4,r4,0x2d00
addi r4,r4,0x40
call fclib_stricmp
cmpwi r3,0x0
bne ShieldOff
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r31, {{ SHIELD_STATE_MEMORY }}@h
ori r31, r31, {{ SHIELD_STATE_MEMORY }}@l
add r31,r12,r31
li r0,0x1
stw r0,0x0(r31)
b Exit

ShieldOff:
lis r4,-0x7fc6
lwz r3,0x14(r1)
addi r4,r4,0x2d00
addi r4,r4,0x43
call fclib_stricmp
cmpwi r3,0x0
bne InvalidValue
lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)
lis r31, {{ SHIELD_STATE_MEMORY }}@h
ori r31, r31, {{ SHIELD_STATE_MEMORY }}@l
add r31,r12,r31
li r0,0x0
stw r0,0x0(r31)
b Exit

InvalidValue:
call Error_InvalidParameterValue

Exit:
li r3,0x1

End:
lwz r0,0x44(r1)
lwz r31,0x3c(r1)
mtspr LR,r0
addi r1,r1,0x40
blr

Next:
lis r4,-0x7fc5