fresload_Load_Main = 0x8028fdf0

.macro call addr
  lis r12,  \addr@h
  ori r12, r12, \addr@l
  mtlr r12
  blrl
.endm

lwz r0,0xdb4(r15)
lis r3,-0x7fc5
subi r4,r3,0x6768
cmpwi r0,0x0
beq Branch
or r4,r0,r0
Branch:
lis r3,-0x7fc5
subi r3,r3,0x675c
li r5,0x0
addi r3,r3,0x9a
call fresload_Load_Main
stw r3,-0x2ab4(r13)
li r3,0x1d8