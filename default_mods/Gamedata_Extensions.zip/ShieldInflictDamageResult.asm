SetUnitHealth = 0x8010d798
_ShieldOff = 0x80123cd4

.macro call addr
  lis r12,  \addr@h
  ori r12, r12, \addr@l
  mtlr r12
  blrl
.endm

lwz r0,0x1fc(r30)
rlwinm. r0,r0,0x0,0x1d,0x1d
beq Branch
or r3,r30,r30
lfs f1,-0x5338(r2)
call SetUnitHealth

Branch:
lfs f1,-0x5334(r2)
lfs f0,0x168(r30)
fcmpu cr0,f1,f0
bne End
or r3,r30,r30
li r4,0x1
call _ShieldOff

End:
lmw r30,0x8(r1)
lwz r0,0x14(r1)
mtspr LR,r0
addi r1,r1,0x10
blr 