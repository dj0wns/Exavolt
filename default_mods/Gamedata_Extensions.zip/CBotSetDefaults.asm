stw r0,0xdcc(r31)

lfs f0,-0x7b44(r13)
lfs f1,-0x756c(r2)

lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)

lis r31, {{ DEADMESHREPLACE_MEMORY }}@h
ori r31, r31, {{ DEADMESHREPLACE_MEMORY }}@l
add r31,r12,r31
stw r0,0x0(r31)

lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)

lis r31, {{ SHIELDARMORPROFILE_MEMORY }}@h
ori r31, r31, {{ SHIELDARMORPROFILE_MEMORY }}@l
add r31,r12,r31
stw r0,0x0(r31)

lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)

lis r31, {{ SHIELDRECHARGE_MEMORY }}@h
ori r31, r31, {{ SHIELDRECHARGE_MEMORY }}@l
add r31,r12,r31
stfs f0,0x0(r31)

lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)

lis r31, {{ SHIELDHEALTH_MEMORY }}@h
ori r31, r31, {{ SHIELDHEALTH_MEMORY }}@l
add r31,r12,r31
stfs f1,0x0(r31)

lis r12, {{ SCRATCH_MEMORY_POINTER }}@h
ori r12, r12, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r12,0x0(r12)

lis r31, {{ SHIELD_STATE_MEMORY }}@h
ori r31, r31, {{ SHIELD_STATE_MEMORY }}@l
add r31,r12,r31
stw r0,0x0(r31)