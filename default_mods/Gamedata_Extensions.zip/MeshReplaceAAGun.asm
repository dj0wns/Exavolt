lwz r0,0xdb4(r31)
cmplwi r0,0x0
beq Branch
or r4,r0,r0
Branch:
lis r3,-0x7fc6