lis r3,-0x7fc6
addi r30,r3,0x49a0
addi r4,r30,0x78
lwz r19,-0x7c94(r13)

lwz r0,0xdb4(r29)
cmplwi r0,0x0
beq Branch1
or r19,r0,r0
Branch1:
lis r28, {{ SCRATCH_MEMORY_POINTER }}@h
ori r28, r28, {{ SCRATCH_MEMORY_POINTER }}@l
lwz r28,0x0(r28)
lis r12, {{ DEADMESHREPLACE_MEMORY }}@h
ori r12, r12, {{ DEADMESHREPLACE_MEMORY }}@l
add r12,r28,r12
lwz r0,0x0(r12)
cmplwi r0,0x0
beq Branch2
or r4,r0,r0
Branch2:
lis r3,-0x7fc6