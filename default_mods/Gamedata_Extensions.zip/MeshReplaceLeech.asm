lwz r0,0xdb4(r31)
lis r3,-0x7fc6
addi r3,r3,0x5bbc
cmpwi r0,0x0
addi r4,r3,0x23
beq Branch
or r4,r0,r0
Branch:
lis r3,-0x7fc6